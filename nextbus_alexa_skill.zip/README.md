# nextbus_alexa_skill
a skill for amazon echo that gets bus stop arrival times via the nextbus api
